import { getSettings, setSettings } from "../shared/settings.js";
import { getRegistrableDomain } from "../shared/url-analyzer.js";
import { hostMatches } from "../shared/hosts.js";

const $ = (selector) => document.querySelector(selector);
const WARNING_URL = chrome.runtime.getURL("src/pages/warning.html");

const LEVELS = {
  safe: ["Aman", "Tidak ada tanda bahaya yang terdeteksi."],
  warn: ["Mencurigakan", "Hati-hati — jangan masukkan password atau data pribadi."],
  block: ["Berbahaya", "Situs ini diblokir oleh Azaya Shield."],
  skip: ["Tidak dianalisis", "Halaman internal browser atau jaringan lokal."],
};

function renderStatus(level, reasons = []) {
  const [title, sub] = LEVELS[level];
  $("#status").className = `status ${level}`;
  $("#statusTitle").textContent = title;
  $("#statusSub").textContent = sub;
  $("#reasons").replaceChildren(
    ...reasons.map((text) => Object.assign(document.createElement("li"), { textContent: text })),
  );
}

function bindToggles(settings) {
  document.querySelectorAll("input[data-key]").forEach((input) => {
    input.checked = Boolean(settings[input.dataset.key]);
    input.addEventListener("change", () => setSettings({ [input.dataset.key]: input.checked }));
  });
}

async function countBlockedOnPage(tabId, since) {
  try {
    const query = since ? { tabId, minTimeStamp: since } : { tabId };
    const { rulesMatchedInfo } = await chrome.declarativeNetRequest.getMatchedRules(query);
    return rulesMatchedInfo.filter((m) => m.rule.rulesetId !== "_dynamic").length;
  } catch {
    return null; // kena rate limit / tidak tersedia
  }
}

function setupPauseButton(tab, url, settings) {
  let host;
  try {
    host = new URL(url).hostname;
  } catch {
    return;
  }
  const button = $("#pauseSite");
  const paused = () => settings.adAllowlist.some((entry) => hostMatches(host, entry));
  const label = () => (button.textContent = paused() ? "Aktifkan lagi ad blocker di situs ini" : "Jeda ad blocker di situs ini");

  button.hidden = false;
  label();
  button.addEventListener("click", async () => {
    const entry = /^[\d.]+$/.test(host) ? host : getRegistrableDomain(host);
    settings.adAllowlist = paused()
      ? settings.adAllowlist.filter((e) => !hostMatches(host, e))
      : [...settings.adAllowlist, entry];
    await setSettings({ adAllowlist: settings.adAllowlist });
    await chrome.runtime.sendMessage({ type: "SYNC_RULES" }); // pastikan rule sudah terpasang sebelum reload
    label();
    chrome.tabs.reload(tab.id);
  });
}

function setupPicker(tab, host, settings) {
  $("#pickerBox").hidden = false;

  const refresh = () => {
    const mine = Object.entries(settings.customHides ?? {}).filter(([key]) => hostMatches(host, key));
    const total = mine.reduce((n, [, v]) => n + (v.selectors?.length ?? 0), 0);
    $("#hidesInfo").hidden = total === 0;
    $("#hidesCount").textContent = `${total} elemen disembunyikan di situs ini`;
  };
  refresh();

  $("#pickElement").addEventListener("click", async () => {
    try {
      await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["src/content/picker.js"] });
      window.close(); // tutup popup supaya halaman bisa diklik
    } catch (err) {
      $("#pickElement").textContent = "Tidak bisa dipakai di halaman ini";
      $("#pickElement").disabled = true;
      console.warn(err);
    }
  });

  $("#clearHides").addEventListener("click", async (e) => {
    e.preventDefault();
    const hides = { ...(settings.customHides ?? {}) };
    for (const key of Object.keys(hides)) if (hostMatches(host, key)) delete hides[key];
    settings.customHides = hides;
    await setSettings({ customHides: hides });
    refresh();
    chrome.tabs.reload(tab.id);
  });
}

function setupProxy(settings) {
  const select = $("#proxySelect");
  const hint = $("#proxyHint");
  const profiles = settings.proxyProfiles ?? [];
  hint.hidden = false;

  if (!profiles.length) {
    hint.textContent = "Belum ada proxy. Tambahkan di Pengaturan lanjutan.";
    return;
  }
  select.hidden = false;
  const off = Object.assign(document.createElement("option"), { value: "", textContent: "Mati (IP asli)" });
  select.replaceChildren(off, ...profiles.map((p) => Object.assign(document.createElement("option"), { value: p.id, textContent: p.label })));
  select.value = settings.proxyMode !== "off" && profiles.some((p) => p.id === settings.proxyProfileId) ? settings.proxyProfileId : "";

  const describe = (mode, id) => {
    if (!id || mode === "off") return "Proxy mati — situs melihat IP aslimu.";
    return mode === "sites" ? "Proxy aktif untuk situs tertentu saja (atur di Pengaturan)." : "Proxy aktif untuk semua situs.";
  };
  hint.textContent = describe(settings.proxyMode, select.value);

  select.addEventListener("change", async () => {
    if (!select.value) {
      await setSettings({ proxyMode: "off" });
      hint.textContent = describe("off", "");
      return;
    }
    const mode = settings.proxyMode === "off" ? "all" : settings.proxyMode;
    settings.proxyMode = mode;
    await setSettings({ proxyProfileId: select.value, proxyMode: mode });
    hint.textContent = describe(mode, select.value);
  });
}

function setupGeo(settings) {
  const select = $("#placeSelect");
  const hint = $("#geoHint");
  const places = settings.fakePlaces ?? [];

  if (!places.length) {
    hint.hidden = false;
    hint.textContent = "Belum ada tempat. Tambahkan di Pengaturan lanjutan.";
    return;
  }
  select.hidden = false;
  select.replaceChildren(
    ...places.map((p) => Object.assign(document.createElement("option"), { value: p.id, textContent: p.label })),
  );
  select.value = places.some((p) => p.id === settings.fakePlaceId) ? settings.fakePlaceId : "";
  if (!select.value) {
    select.prepend(Object.assign(document.createElement("option"), { value: "", textContent: "— pilih tempat —", selected: true }));
  }
  select.addEventListener("change", () => setSettings({ fakePlaceId: select.value }));
  hint.hidden = false;
  hint.textContent = "Berlaku untuk permintaan lokasi berikutnya. Muat ulang halaman yang sudah terbuka.";
}

async function init() {
  const settings = await getSettings();
  bindToggles(settings);
  setupGeo(settings);
  setupProxy(settings);
  $("#threatsCount").textContent = settings.threatsBlocked.toLocaleString("id-ID");
  $("#openOptions").addEventListener("click", (e) => {
    e.preventDefault();
    chrome.runtime.openOptionsPage();
  });

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.url) return renderStatus("skip");

  // Tab sedang menampilkan halaman peringatan → tampilkan info situs yang diblokir.
  if (tab.url.startsWith(WARNING_URL)) {
    const params = new URL(tab.url).searchParams;
    let reasons = [];
    try { reasons = JSON.parse(params.get("reasons") ?? "[]"); } catch { /* abaikan */ }
    try { $("#host").textContent = new URL(params.get("url")).hostname; } catch { /* abaikan */ }
    $("#adsCount").textContent = "–";
    return renderStatus("block", reasons);
  }

  if (!/^https?:/.test(tab.url)) {
    $("#host").textContent = "Halaman browser";
    return renderStatus("skip");
  }

  $("#host").textContent = new URL(tab.url).hostname;
  setupPauseButton(tab, tab.url, settings);
  setupPicker(tab, new URL(tab.url).hostname, settings);

  const status = await chrome.runtime.sendMessage({ type: "GET_TAB_STATUS", tabId: tab.id, url: tab.url });
  if (!status || status.error || status.skipped) renderStatus("skip");
  else renderStatus(status.level, status.reasons.map((r) => r.label));

  const count = await countBlockedOnPage(tab.id, status?.at);
  $("#adsCount").textContent = count === null ? "–" : String(count);
}

init();
